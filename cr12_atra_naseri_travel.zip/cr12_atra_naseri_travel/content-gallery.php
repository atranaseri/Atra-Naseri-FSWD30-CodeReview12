<div class="blog-post post-gallery">
	<div class="well">
		<h2><?php the_title(); ?></h2>
		<?php the_content(); ?>
	</div>
	
</div>