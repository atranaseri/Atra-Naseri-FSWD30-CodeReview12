<div class="blog-post post-aside">
	<div class="well">
		<small><?php the_author(); ?>@<?php the_Date(); ?></small>
		<?php the_content(); ?>
	</div>
	
</div>